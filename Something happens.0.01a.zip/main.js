/*! thoughts var, <kill or replace> thoughts button </kill or replace> thoughts display 
Replace thoughts button with timer.  Kill button.  */

var thoughts = 0;
Function thoughtClick(number){
	thoughts = thoughts + number;
document.getElementByID("thoughts").innerHTML = thoughts;
};