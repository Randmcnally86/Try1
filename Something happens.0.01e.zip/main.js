/*! thoughts var, <kill or replace> thoughts button </kill or replace> thoughts display 
Replace thoughts button with timer.  Kill button.  */

var thoughts = 0;
function thoughtClick(number){
	thoughts = thoughts + number;
document.getElementById("thoughts").innerHTML = thoughts;
};

window.setInterval(function(){
	
	thoughtClick(1);
	
}, 1000);